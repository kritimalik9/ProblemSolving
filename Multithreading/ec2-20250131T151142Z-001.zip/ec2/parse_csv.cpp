template<uint32_t MAX_NUM_FIELDS>
uint32_t parseCsvData(char* buf, char* fields[MAX_NUM_FIELDS])
{
    uint32_t k = 0;
    bool isFieldSet = false;
    size_t i = 0;
    bool isFieldString = false;
    while(buf[i])
    {
        char ch = buf[i];
        if(ch == '\"')
        {
            isFieldString = !isFieldString;
        }
        if(!isFieldSet)
        {
            fields[k++] = buf + i;
            if(ch == ',')
            {
            	buf[i] = 0x00;
                ++i;
            	isFieldSet = false;
                continue;
            }
            else
            {
                isFieldSet = true;
            }
        }
        if(!isFieldString && buf[i+1] == ',') //to handle [,,]
        {
        	++i;
        	buf[i] = 0x00;
        	isFieldSet = false;
        }
        ++i;
    }
    return k;
}

parseSomeData(const Cfg* a_Cfg,
    char* a_IndexDataLine
    )
{
	char* buf = a_IndexDataLine;
	char empty[] = {0};
    
    char* fields[16] = {empty}; //16 entries

    uint32_t k = parseCsvData<16>(buf, fields);

	if(k<16) return eError_InvalidField; //too few fields

    SomeData someData;
    if(fields[5] != nullptr)
    {
        someData.m_field = std::atoi(fields[5]);
    }
}    
read_csv(const char* path) 
{
    auto errCode = eSuccess;
    FILE* filePtr = fopen(filePath,"r");
    if(filePtr)
    {
        setvbuf (filePtr , NULL , _IOFBF , 1024*1024*2); //set buffer to 2 MB
        std::cout << "Start reading input file " << filePath << std::endl;
        char line[1024];
		auto startTime = std::chrono::steady_clock::now();
        fgets (line , sizeof(line) , filePtr); //skip header
	    uint32_t readLinesCnt = 0;
        while(fgets (line , sizeof(line) , filePtr) != NULL)
        {
            ++readLinesCnt;
            errCode = parseSomeData(line);
            if(errCode != eSuccess)
            {
                if(fgets (line , sizeof(line) , filePtr) != NULL)
                {
                    std::cout << "Failed to parse SPIdx data line:" << line
                              << ", LineNum: " << readLinesCnt
                              << std::endl;
                    break;
                }
                else
                {
                    errCode = eSuccess;
                }
            }
        }
        const auto endTime = std::chrono::steady_clock::now();
	    fclose(filePtr);
        using namespace std::literals;
        auto elapsedSeconds = (endTime - startTime)/1s;
        std::cout << "Reading finished, time elapsed = " << elapsedSeconds << "s." << std::endl;
    }

}
