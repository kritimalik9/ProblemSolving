# IMP_NOTE

1.Topological sort
2.Dijktra
3.Bellman Ford
4.Google Summer of Code: Home
5.Practice mock interviews by pramp
6.William Fist & Tushar Roy
7.System Design educative.io - Repetition 3 times 
8.Tushar Roy, Tech Dummies Narener L, CodeKarle
9.DONT Jump directly to solve the problem in interview, 
  FIRST fully understand the problem what was asking by Trying few input & output examples.